﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Projekt2.Models;

namespace Projekt2.ViewModels.EntryVM
{
    public class SearchIndexVM
    {
        public List<Entry> EntriesList { get; set; }
    }
}