﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Projekt2.Models;

namespace Projekt2.ViewModels.EntryVM
{
    public class NotesVM
    {
        public Entry entry { get; set; }
    }
}